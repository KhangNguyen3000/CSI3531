import java.io.File;
import java.nio.CharBuffer;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.channels.FileChannel.MapMode;
import java.nio.file.StandardOpenOption;
import java.util.Scanner;

/*
 * java na pas un facons de facons native pour shared emory, cependent les memory mapped files accomply le meme chose (https://en.wikipedia.org/wiki/Memory-mapped_file).
 * A memory-mapped file is a segment of virtual memory that has been assigned a direct byte-for-byte correlation with some portion of a file or file-like resource. This 
 * resource is typically a file that is physically present on disk, but can also be a device, shared memory object, or other resource that the operating system can reference 
 * through a file descriptor. Once present, this correlation between the file and the memory space permits applications to treat the mapped portion as if it were primary memory.
 * */

public class question3Producer {

	
	public static int factorial(int n) {
		int answer = 1;
		
		for (int i = 1; i < n; i++) {
			answer = answer*(i+1);
		}
		return answer;
	}
	
	public static void main( String[] args ) throws Throwable {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Insert Catalan number index: ");
		int n = scanner.nextInt();
		scanner.close();
		
		int answer = (factorial(2*n))/(factorial(n+1)*factorial(n));
		
		
		
        File f = new File( "TMP" );

        FileChannel channel = FileChannel.open( f.toPath(), StandardOpenOption.READ, StandardOpenOption.WRITE, StandardOpenOption.CREATE );

        MappedByteBuffer b = channel.map( MapMode.READ_WRITE, 0, 4096 );
        CharBuffer charBuf = b.asCharBuffer();

        char[] string = (answer+"\0").toCharArray();//creer un char array d'un string qui fini avec escape character \0
        charBuf.put( string );//insere le char array

        System.out.println( "Waiting for Consumer" );
        while( charBuf.get( 0 ) != '\0' );//attends pour escape character \0
        System.out.println( "Done" );
	}
}
