import java.io.File;
import java.nio.CharBuffer;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.channels.FileChannel.MapMode;
import java.nio.file.StandardOpenOption;

/*
 * java na pas un facons de facons native pour shared emory, cependent les memory mapped files accomply le meme chose (https://en.wikipedia.org/wiki/Memory-mapped_file).
 * A memory-mapped file is a segment of virtual memory that has been assigned a direct byte-for-byte correlation with some portion of a file or file-like resource. This 
 * resource is typically a file that is physically present on disk, but can also be a device, shared memory object, or other resource that the operating system can reference 
 * through a file descriptor. Once present, this correlation between the file and the memory space permits applications to treat the mapped portion as if it were primary memory.
 * */

public class question3Consumer {

    public static void main( String[] args ) throws Throwable {
        File f = new File( "TMP" );
        FileChannel channel = FileChannel.open( f.toPath(), StandardOpenOption.READ, StandardOpenOption.WRITE, StandardOpenOption.CREATE );

        MappedByteBuffer b = channel.map( MapMode.READ_WRITE, 0, 4096 );
        CharBuffer charBuf = b.asCharBuffer();


        char c;
        while( ( c = charBuf.get() ) != 0 ) {//print c si il n'est pas egale au escape character \0
            System.out.print( c );
        }
        System.out.println();

        charBuf.put( 0, '\0' );//envoie escape character \0
    }
	
}
