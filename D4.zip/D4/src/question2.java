import java.util.Arrays;
import java.util.Scanner;
import java.lang.Math;
import java.util.LinkedList; 
import java.util.Queue;
import java.util.List; 
import java.util.ArrayList; 

public class question2 {

	private static void fifo(int[] refString, int lenOfFrames) {
		System.out.println("Starting FIFO with reference string "+Arrays.toString(refString));
		int pageFault = 0;
		
		Queue<Integer> frames = new LinkedList<>(); 
		for(int i = 0; i < refString.length; i++) {//pour chaque element du reference string
			boolean there = false;//si la page est deja dans un frame, commence a false
			for(Integer frame: frames) {
				if (refString[i] == frame) {
					there = true;//la page est dans un frame donc skip if(there= false)
					break;//break parce qu'on sait elle est deja la
				}
			}
			if (there == false){//si la page n'est pas dans un frame deja
				pageFault++;//augmente page fault
				if(frames.size() >= lenOfFrames) {//si tous les frames sont full
					frames.remove();//enleve la page le plus vieux
				}
				frames.add(refString[i]);//ajoute la page au frame
			}
		}
		System.out.println("FIFO Page Faults: "+pageFault);
	}
	
	private static void lru(int[] refString, int lenOfFrames) {
		System.out.println("Starting LRU with reference string "+Arrays.toString(refString));
		int[] lastUsedCounter = new int[10];//compte le dernier fois que chaque apge a ete utiliser
		int pageFault = 0;//page faults
		
		List<Integer> frames = new ArrayList<>(); 
		for(int i = 0; i < refString.length; i++) {//pour chaque element du reference string
			boolean there = false;//si la page est deja dans un frame, commence a false
			for(int j = 0; j < lastUsedCounter.length; j++) {//increment counter pour tous numeros sauf celui qui est entrein detre ajouter (set celui la a 0)
				if(j != refString[i]) {
					lastUsedCounter[j]++;//increment
				}else {
					lastUsedCounter[j] = 0;//set a 0 le current page counter (page a etre ajouter)
				}
			}
			for(int j = 0; j < frames.size(); j++) {//check si la page est deja dans un frame
				if (refString[i] == frames.get(j)) {
					there = true;//la page est dans un frame
					break;
				}
			}
			if (there == false){
				pageFault++;//incrememnt page fault
					if(frames.size() >= lenOfFrames) {//fait ceci si les frames sont rempli
						int leastRecentlyUsedCounterFromFrame = 0;//ceci vas etre egale a au valeur du frame avec la page le moins recamment utiliser
						int leastRU = 0;//ceci vas etre egale a l'index du frame avec la page le moins recamment utiliser
						for(int k = 0; k < frames.size(); k++) {//pour chaque frame
							if(lastUsedCounter[frames.get(k)] > leastRecentlyUsedCounterFromFrame) {//si le nombre de cycle sans utilisation est plus elever que le precendent (seulement plus grand pour FIFO)
								leastRecentlyUsedCounterFromFrame = lastUsedCounter[frames.get(k)];//sauve le valeur
								leastRU = k;//sauve l'index
							}
						}
						frames.remove(leastRU);//enleve le moins recamment utiliser
					}
					frames.add(refString[i]);//ajoute la nouvelle page
				}
			}
		System.out.println("LRU Page Faults: "+pageFault);
	}
	
	
	public static void main(String args[]) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Insert Length of Reference String: ");
		int lenOfString = scanner.nextInt();
		int[] refString = new int[lenOfString];
		System.out.println("Insert Number of Page Frames: ");
		int lenOfFrames = scanner.nextInt();
		scanner.close();
		
		for(int i =0; i < lenOfString; i++) {
			refString[i] = ((int) (Math.random()*10));
		}
		fifo(refString, lenOfFrames);
		lru(refString, lenOfFrames);
	}
}
